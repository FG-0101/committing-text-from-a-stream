Committing text from a stream: reproduction

Requirements
Python 3.14 (Unicode 16.0 data in unicodedata), Node.js 24, and an ICU library whose C normalization functions can be loaded with ctypes. The reference run used Python 3.14.7, Node 24.19.0 and ICU 78.1.

Command
python3.14 -B reproduce.py --node /path/to/node

Five stages run in a new directory runs/<UTC timestamp>/: the Python and ICU pass over the test data (code/compute.py), the Node pass (code/verify.mjs), a row-by-row comparison of the two (code/crosscheck.py), the pending-buffer construction (code/buffer.py) and the lifecycle cases (code/lifecycle.py). Each stage has an 18-second CPU limit; use --cpu-limit 120 if the machine is slow. Stage output is stored next to the results, together with processes.json.

The summaries are then checked against expected.json. Runtime, Unicode and ICU version fields, ICU call counts and timings are not compared. On success the command prints PASS and writes CHECK.json.

Expected counts
19,965 source rows; 100,664 single byte cuts per normalization form; 402,656 executions of the exact pipeline; 7,062 NFC cut failures with independently normalized chunks and 49 NFC rows that fail with the class-zero boundary rule.

Data
data/NormalizationTest-16.0.0.txt is the Unicode 16.0 normalization test file, distributed under data/UNICODE-LICENSE.txt.

Files
RESULTS.tsv lists the program, line and output path behind each table. ENVIRONMENT.json describes the reference run.
