"""Reconcile every stored cross-runtime row and its finite coverage."""
from pathlib import Path
import argparse,gzip,json
ap=argparse.ArgumentParser();ap.add_argument('primary',type=Path);ap.add_argument('node',type=Path);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists()
p=json.loads((a.primary/'summary.json').read_text());q=json.loads((a.node/'summary.json').read_text());assert p['failure_count']==q['failure_count']==0
with gzip.open(a.primary/'rows.jsonl.gz','rt') as f:primary=[json.loads(x) for x in f]
node=[json.loads(x) for x in (a.node/'rows.jsonl').read_text().splitlines()];assert len(primary)==len(node)==19965
assert len({x['line'] for x in primary})==19965
for x,y in zip(primary,node):
 assert x['line']==y['line'] and x['bytes']==y['bytes'] and x['bad_decode_cuts']==y['bad_decode_cuts']
assert sum(x['bytes']+1 for x in primary)==p['counts']['byte_cuts']==q['byte_cuts']
assert sum(len(x['bad_decode_cuts']) for x in primary)==q['independent_decode_cut_failures']==49995
for form in ['NFC','NFD','NFKC','NFKD']:
 c=p['forms'][form];assert c['independent_char_cut_failures']==sum(len(x['forms'][form]['independent_bad_cuts']) for x in primary)
 assert c.get('ccc_zero_row_failures',0)==sum(x['forms'][form]['ccc_zero_failed'] for x in primary)
assert p['counts']['normalization_equations_per_runtime']==q['normalization_equations']==19965*20
report={'status':'PASS','source_rows':len(primary),'byte_cuts_each':q['byte_cuts'],'normalization_equations_each':q['normalization_equations'],'mismatched_stored_rows':0};a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
