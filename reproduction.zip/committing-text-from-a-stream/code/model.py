"""Incremental UTF-8 plus normalization using the existing ICU boundary contract."""
import codecs
import ctypes as C
import ctypes.util
import functools
import sys
import unicodedata as U

FORMS = ('NFC', 'NFD', 'NFKC', 'NFKD')

class ICU:
    def __init__(self):
        name = ctypes.util.find_library('icuuc')
        self.lib = C.CDLL(name or '/usr/lib/libicucore.A.dylib')
        def symbol(name):
            for tail in [''] + ['_' + str(v) for v in range(90, 49, -1)]:
                try:
                    return getattr(self.lib, name + tail)
                except AttributeError:
                    pass
            raise RuntimeError('ICU symbol unavailable: ' + name)
        self.version = []
        for name in ['u_getVersion', 'u_getUnicodeVersion']:
            f = symbol(name); f.argtypes = [C.POINTER(C.c_uint8)]; f.restype = None
            v = (C.c_uint8 * 4)(); f(v); self.version.append('.'.join(map(str, v)))
        self.ptr = {}
        for form in FORMS:
            f = symbol('unorm2_get' + form + 'Instance')
            f.argtypes = [C.POINTER(C.c_int32)]; f.restype = C.c_void_p
            status = C.c_int32(0); self.ptr[form] = f(C.byref(status))
            if status.value > 0 or not self.ptr[form]: raise RuntimeError(status.value)
        self.norm = symbol('unorm2_normalize')
        self.norm.argtypes = [C.c_void_p, C.POINTER(C.c_uint16), C.c_int32,
                              C.POINTER(C.c_uint16), C.c_int32, C.POINTER(C.c_int32)]
        self.norm.restype = C.c_int32
        self.boundary = symbol('unorm2_hasBoundaryBefore')
        self.boundary.argtypes = [C.c_void_p, C.c_int32]; self.boundary.restype = C.c_int8
        self.calls = 0

    @functools.lru_cache(maxsize=131072)
    def normalize(self, form, text):
        codec = 'utf-16-le' if sys.byteorder == 'little' else 'utf-16-be'
        raw = text.encode(codec); n = len(raw) // 2
        source = (C.c_uint16 * n).from_buffer_copy(raw)
        capacity = max(32, n * 20 + 16)
        while True:
            dest = (C.c_uint16 * capacity)(); status = C.c_int32(0)
            length = self.norm(self.ptr[form], source, n, dest, capacity, C.byref(status))
            self.calls += 1
            if status.value == 15:
                capacity = length + 1; continue
            if status.value > 0: raise RuntimeError(('ICU normalize', status.value))
            return bytes(dest)[:length * 2].decode(codec)

    @functools.lru_cache(maxsize=131072)
    def before(self, form, char):
        return bool(self.boundary(self.ptr[form], ord(char)))

class Normalizer:
    def __init__(self, icu, form, heuristic=False):
        self.icu = icu; self.form = form; self.heuristic = heuristic
        self.pending = ''; self.closed = False; self.peak_pending = 0
    def feed(self, text, final=False):
        if self.closed: raise ValueError('stream already completed')
        output = []
        for char in text:
            boundary = U.combining(char) == 0 if self.heuristic else self.icu.before(self.form, char)
            if boundary and self.pending:
                output.append(self.icu.normalize(self.form, self.pending)); self.pending = ''
            self.pending += char; self.peak_pending = max(self.peak_pending, len(self.pending))
        if final:
            output.append(self.icu.normalize(self.form, self.pending)); self.pending = ''; self.closed = True
        return ''.join(output)

class Pipeline:
    def __init__(self, icu, form, errors='strict'):
        self.decoder = codecs.getincrementaldecoder('utf-8')(errors)
        self.normalizer = Normalizer(icu, form); self.closed = False
    def feed(self, chunk, final=False):
        if self.closed: raise ValueError('stream already completed')
        try:
            chars = self.decoder.decode(chunk, final=final)
            return self.normalizer.feed(chars, final=final)
        except UnicodeError:
            self.closed = True
            raise
        finally:
            if final: self.closed = True

def stream_safe(text):
    """UAX15-D4 reference process; it is a separate transformation from normalization."""
    count = 0; output = []
    for char in text:
        decomp = U.normalize('NFKD', char)
        classes = [U.combining(c) for c in decomp]
        leading = 0
        for value in classes:
            if value == 0: break
            leading += 1
        if count + leading > 30:
            output.append('\u034f'); count = 0
        output.append(char)
        if all(classes): count += len(classes)
        else:
            count = 0
            for value in reversed(classes):
                if value == 0: break
                count += 1
    return ''.join(output)

def rows(path):
    for line_no, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        clean = line.split('#', 1)[0].strip()
        if not clean or clean.startswith('@'): continue
        columns = [''.join(chr(int(c, 16)) for c in x.split()) for x in clean.split(';')[:5]]
        if len(columns) != 5: raise ValueError(('bad row', line_no))
        yield line_no, columns

def expected_columns(columns, form):
    if form == 'NFC': return [columns[1]] * 3 + [columns[3]] * 2
    if form == 'NFD': return [columns[2]] * 3 + [columns[4]] * 2
    return [columns[3 if form == 'NFKC' else 4]] * 5

def points(s): return ['%04X' % ord(c) for c in s]
