from pathlib import Path
import argparse,json
from model import ICU,Pipeline
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();assert not a.output.exists()
rows=[]
for raw,errors in [(b'\xc3','strict'),(b'\xc3','replace'),(b'\xff','strict'),(b'','strict'),('e\u0301'.encode(),'strict')]:
 q=Pipeline(ICU(),'NFC',errors);rec={'input_hex':raw.hex(),'errors':errors}
 try:rec['output']=q.feed(raw,final=True)
 except UnicodeDecodeError:rec['error']='UnicodeDecodeError'
 try:q.feed(b'A');raise AssertionError('input accepted after terminal event')
 except ValueError:rec['rejected_after_terminal']=True
 rows.append(rec)
a.output.write_text(json.dumps({'status':'PASS','cases':rows},indent=2)+'\n');print(json.dumps({'status':'PASS','cases':len(rows)}))
