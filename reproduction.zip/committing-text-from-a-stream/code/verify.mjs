// Node TextDecoder and String.prototype.normalize checks over the normalization test data.
import fs from 'node:fs';
const [input, output] = process.argv.slice(2);
if (!input || !output || fs.existsSync(output)) throw Error('Supply the input file and a new output path');
fs.mkdirSync(output, {recursive:true});
const source=fs.readFileSync(input), forms=['NFC','NFD','NFKC','NFKD'];
let rows=0, byteCuts=0, equations=0, naiveFailures=0, failures=[];
const records=[];
for (const [index,line] of source.toString('utf8').split(/\r?\n/).entries()) {
  const clean=line.split('#')[0].trim(); if (!clean || clean.startsWith('@')) continue;
  const cols=clean.split(';').slice(0,5).map(x=>String.fromCodePoint(...x.trim().split(/\s+/).filter(Boolean).map(y=>parseInt(y,16))));
  rows++; const raw=Buffer.from(cols[0],'utf8'), bad=[];
  for (const form of forms) {
    const want=form==='NFC'?[cols[1],cols[1],cols[1],cols[3],cols[3]]:form==='NFD'?[cols[2],cols[2],cols[2],cols[4],cols[4]]:Array(5).fill(cols[form==='NFKC'?3:4]);
    for (let k=0;k<5;k++) {equations++;if(cols[k].normalize(form)!==want[k])failures.push({line:index+1,form,column:k});}
  }
  for (let cut=0;cut<=raw.length;cut++) {
    byteCuts++; const d=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
    const got=d.decode(raw.subarray(0,cut),{stream:true})+d.decode(new Uint8Array(),{stream:true})+d.decode(raw.subarray(cut),{stream:true})+d.decode();
    if(got!==cols[0])failures.push({line:index+1,cut,kind:'incremental_decode'});
    const sep=new TextDecoder('utf-8',{ignoreBOM:true}).decode(raw.subarray(0,cut))+new TextDecoder('utf-8',{ignoreBOM:true}).decode(raw.subarray(cut));
    if(sep!==cols[0]){bad.push(cut);naiveFailures++;}
  }
  const d=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}); let bytewise='';
  for (const b of raw) {bytewise+=d.decode(Uint8Array.of(b),{stream:true});bytewise+=d.decode(new Uint8Array(),{stream:true});}
  bytewise+=d.decode();if(bytewise!==cols[0])failures.push({line:index+1,kind:'bytewise'});
  records.push(JSON.stringify({line:index+1,bytes:raw.length,bad_decode_cuts:bad}));
}
const traces=[];
for(const [name,raw] of [['truncated',Buffer.from([0xc3])],['split_scalar',Buffer.from([0xc3,0xa9])],['BOM',Buffer.from([0xef,0xbb,0xbf,0x41])]]) {
  for(const fatal of [false,true]) for(const ignoreBOM of [false,true]) {
    const d=new TextDecoder('utf-8',{fatal,ignoreBOM});const events=[];
    try {for(const b of raw)events.push({final:false,input_hex:b.toString(16).padStart(2,'0'),output:Array.from(d.decode(Uint8Array.of(b),{stream:true})).map(c=>c.codePointAt(0))});events.push({final:true,output:Array.from(d.decode()).map(c=>c.codePointAt(0))});}
    catch(e){events.push({error:e.name});}
    traces.push({name,fatal,ignoreBOM,events});
  }
}
const summary={rows,byte_cuts:byteCuts,normalization_equations:equations,independent_decode_cut_failures:naiveFailures,failures,failure_count:failures.length,node:process.version,versions:process.versions,BOM_policy:'Preserve initial U+FEFF with ignoreBOM:true; default stripping is a distinct contract.'};
fs.writeFileSync(output+'/rows.jsonl',records.join('\n')+'\n');fs.writeFileSync(output+'/summary.json',JSON.stringify(summary,null,2)+'\n');fs.writeFileSync(output+'/traces.json',JSON.stringify(traces,null,2)+'\n');console.log(JSON.stringify({rows,byteCuts,equations,naiveFailures,failure_count:failures.length}));if(failures.length)process.exitCode=1;
