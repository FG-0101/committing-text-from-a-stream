"""Check every row of the normalization corpus."""
from pathlib import Path
import argparse, codecs, collections, gzip, itertools, json, os, sys, time
import unicodedata as U
from model import ICU, FORMS, Normalizer, Pipeline, rows, expected_columns, stream_safe, points

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--start', type=int, default=0); ap.add_argument('--stop', type=int)
    args = ap.parse_args(); args.output.mkdir(parents=True, exist_ok=False)
    data = Path(__file__).resolve().parents[1] / 'data/NormalizationTest-16.0.0.txt'
    all_rows = list(rows(data)); selected = all_rows[args.start:args.stop]
    icu = ICU(); counts = collections.Counter(); form_counts = {f: collections.Counter() for f in FORMS}
    failures = []; examples = {}; begin = time.monotonic()
    assert U.unidata_version == '16.0.0', ('primary Unicode version', U.unidata_version)
    def fail(kind, line, **extra): failures.append(dict(kind=kind, line=line, **extra))
    with gzip.open(args.output / 'rows.jsonl.gz', 'wt', encoding='utf-8', newline='\n') as record:
        for line, cols in selected:
            s = cols[0]; raw = s.encode('utf-8'); counts['rows'] += 1
            out = {'line':line, 'bytes':len(raw), 'codepoints':len(s), 'bad_decode_cuts':[], 'forms':{}}
            expected = {f: cols[i+1] for i,f in enumerate(FORMS)}
            for f in FORMS:
                target = expected_columns(cols, f)
                for index, (value, want) in enumerate(zip(cols, target)):
                    counts['normalization_equations_per_runtime'] += 1
                    if U.normalize(f,value) != want: fail('python_corpus',line,form=f,column=index)
                    if icu.normalize(f,value) != want: fail('icu_corpus',line,form=f,column=index)
                bad = []; heuristic = Normalizer(icu,f,True)
                h_result = heuristic.feed(s,final=True)
                for cut in range(len(s)+1):
                    form_counts[f]['independent_char_cuts'] += 1
                    got = U.normalize(f,s[:cut]) + U.normalize(f,s[cut:])
                    if got != expected[f]:
                        bad.append(cut); form_counts[f]['independent_char_cut_failures'] += 1
                        examples.setdefault('independent_'+f, {'line':line,'cut':cut,'input':points(s),'actual':points(got),'expected':points(expected[f])})
                if h_result != expected[f]:
                    form_counts[f]['ccc_zero_row_failures'] += 1
                    examples.setdefault('ccc_zero_'+f, {'line':line,'input':points(s),'actual':points(h_result),'expected':points(expected[f])})
                out['forms'][f] = {'independent_bad_cuts':bad,'ccc_zero_failed':h_result!=expected[f]}
            for cut in range(len(raw)+1):
                counts['byte_cuts'] += 1
                decoder = codecs.getincrementaldecoder('utf-8')('strict')
                left = decoder.decode(raw[:cut],False); empty = decoder.decode(b'',False)
                right = decoder.decode(raw[cut:],False); tail = decoder.decode(b'',True)
                if left+empty+right+tail != s: fail('incremental_decode',line,cut=cut)
                naive = raw[:cut].decode('utf-8','replace') + raw[cut:].decode('utf-8','replace')
                if naive != s:out['bad_decode_cuts'].append(cut);counts['independent_decode_cut_failures'] += 1
                for f in FORMS:
                    stream = Normalizer(icu,f); emitted = ''
                    for chunk, final in [(left,False),(empty,False),(right,False),(tail,True)]:
                        emitted += stream.feed(chunk,final)
                        form_counts[f]['observed_prefix_checks'] += 1
                        if not expected[f].startswith(emitted):fail('observed_prefix',line,form=f,cut=cut)
                    form_counts[f]['pipeline_byte_cuts'] += 1
                    if emitted != expected[f]:fail('pipeline_final',line,form=f,cut=cut)
            pipes = {f:Pipeline(icu,f) for f in FORMS}; got={f:'' for f in FORMS}
            for byte in raw:
                for f in FORMS:
                    got[f] += pipes[f].feed(bytes([byte])); got[f] += pipes[f].feed(b'')
            for f in FORMS:
                got[f] += pipes[f].feed(b'',True);form_counts[f]['bytewise_empty_cases'] += 1
                if got[f] != expected[f]:fail('bytewise',line,form=f)
            record.write(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n')
    # Exact traces cover EOF, BOM, malformed input and known unsafe boundary controls.
    traces=[]
    for label, raw, cuts, errors in [('split_scalar',b'\xc3\xa9',[1],'replace'),('truncated',b'\xc3',[1],'replace'),('truncated_strict',b'\xc3',[1],'strict'),('bom',b'\xef\xbb\xbfA',[1,2],'strict'),('composition','e\u0301'.encode(),[1],'strict'),('hangul','\u1100\u1161'.encode(),[3],'strict')]:
        chunks=[]; last=0
        for cut in cuts+[len(raw)]:chunks.append(raw[last:cut]);last=cut
        p=Pipeline(icu,'NFC',errors);events=[]
        try:
            for c in chunks:events.append({'input_hex':c.hex(),'final':False,'output':points(p.feed(c))})
            events.append({'input_hex':'','final':True,'output':points(p.feed(b'',True))})
        except UnicodeDecodeError as e:events.append({'error':type(e).__name__,'reason':e.reason,'final':True})
        traces.append({'name':label,'errors':errors,'events':events})
    family=[]
    for n in range(1,13):
        states=set();distinct=set()
        for bits in itertools.product([0x300,0x301],repeat=n):
            s='2'+''.join(map(chr,bits));p=Normalizer(icu,'NFD');emitted=p.feed(s)
            assert U.normalize('NFD',s+'\u0327').startswith(emitted)
            # Appended lower-class mark precedes every variable mark: none can be emitted.
            assert len(emitted)<=1
            states.add(p.pending);distinct.add(U.normalize('NFD',s+'\u0327'))
        family.append({'n':n,'inputs':2**n,'distinct_pending':len(states),'distinct_completed_outputs':len(distinct)})
        assert len(states)==len(distinct)==2**n
    long=[]
    for n in [0,1,29,30,31,60,61,1000]:
        s='2'+'\u0301'*n;exact=U.normalize('NFC',s);safe=U.normalize('NFC',stream_safe(s));p=Normalizer(icu,'NFC');parts=[p.feed(c) for c in s];parts.append(p.feed('',True));assert ''.join(parts)==exact
        long.append({'nonstarters':n,'exact_codepoints':len(exact),'stream_safe_codepoints':len(safe),'CGJ_insertions':safe.count('\u034f'),'same_exact_output':safe==exact,'canonically_equivalent':U.normalize('NFD',safe)==U.normalize('NFD',exact),'peak_pending_codepoints':p.peak_pending})
    summary={'range':[args.start,args.stop],'corpus_rows':len(all_rows),'selected_rows':len(selected),'counts':dict(counts),'forms':{f:dict(x) for f,x in form_counts.items()},'failures':failures,'failure_count':len(failures),'python':sys.version,'python_unicode':U.unidata_version,'icu_version':icu.version[0],'icu_unicode':icu.version[1],'icu_normalization_calls':icu.calls,'seconds':time.monotonic()-begin}
    for name,obj in [('summary',summary),('counterexamples',examples),('boundary_traces',traces),('buffer_family',family),('stream_safe_comparison',long)]:
        (args.output/(name+'.json')).write_text(json.dumps(obj,ensure_ascii=True,indent=2)+'\n')
    print(json.dumps(summary,sort_keys=True));assert not failures

if __name__=='__main__': main()
