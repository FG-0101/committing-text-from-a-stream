"""Finite witnesses for the no-starter information-retention proof."""
from pathlib import Path
import argparse,itertools,json,unicodedata as U
from model import ICU,Normalizer
ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists()
icu=ICU();rows=[]
for n in range(1,13):
    pending=set();outputs=set();emitted=set()
    for bits in itertools.product([0x300,0x301],repeat=n):
        v=''.join(map(chr,bits));p=Normalizer(icu,'NFD');o=p.feed(v);emitted.add(o);pending.add(p.pending)
        final=o+p.feed('\u0327',final=True);want=U.normalize('NFD',v+'\u0327')
        assert final==want=='\u0327'+v;outputs.add(final)
    assert emitted=={''};assert len(pending)==len(outputs)==2**n
    rows.append({'n':n,'inputs':2**n,'distinct_pending':len(pending),'distinct_outputs':len(outputs),'nonempty_emissions_before_continuation':0})
a.output.write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'families':len(rows),'strings':sum(x['inputs'] for x in rows),'failures':0}))
